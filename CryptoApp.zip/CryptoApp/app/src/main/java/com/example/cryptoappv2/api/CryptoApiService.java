package com.example.cryptoappv2.api;

import com.example.cryptoappv2.model.Cryptocurrency;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface CryptoApiService {
    @GET("api/v3/coins/markets")
    Call<List<Cryptocurrency>> getCryptocurrencies(
            @Query("vs_currency") String currency,
            @Query("order") String order,
            @Query("per_page") int perPage,
            @Query("page") int page,
            @Query("sparkline") boolean sparkline
    );
}