package com.example.cryptoappv2.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.cryptoappv2.R;
import com.example.cryptoappv2.model.Cryptocurrency;
import com.example.cryptoappv2.ui.DetailActivity;

import java.util.List;
import java.util.Locale;

public class CryptoAdapter extends RecyclerView.Adapter<CryptoAdapter.CryptoViewHolder> {
    private Context context;
    private List<Cryptocurrency> cryptoList;

    public CryptoAdapter(Context context, List<Cryptocurrency> cryptoList) {
        this.context = context;
        this.cryptoList = cryptoList;
    }

    @NonNull
    @Override
    public CryptoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_crypto, parent, false);
        return new CryptoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CryptoViewHolder holder, int position) {
        Cryptocurrency crypto = cryptoList.get(position);
        
        holder.nameTextView.setText(crypto.getName());
        holder.symbolTextView.setText(crypto.getSymbol().toUpperCase());
        holder.priceTextView.setText(String.format(Locale.US, "$%.2f", crypto.getCurrentPrice()));
        
        double priceChange = crypto.getPriceChangePercentage24h();
        holder.changeTextView.setText(String.format(Locale.US, "%.2f%%", priceChange));
        
        if (priceChange < 0) {
            holder.changeTextView.setTextColor(Color.RED);
        } else {
            holder.changeTextView.setTextColor(Color.GREEN);
        }
        
        Glide.with(context)
                .load(crypto.getImageUrl())
                .into(holder.iconImageView);
        
        holder.cardView.setOnClickListener(v -> {
            Intent intent = new Intent(context, DetailActivity.class);
            intent.putExtra("CRYPTO_ID", crypto.getId());
            intent.putExtra("CRYPTO_NAME", crypto.getName());
            intent.putExtra("CRYPTO_SYMBOL", crypto.getSymbol());
            intent.putExtra("CRYPTO_PRICE", crypto.getCurrentPrice());
            intent.putExtra("CRYPTO_CHANGE", crypto.getPriceChangePercentage24h());
            intent.putExtra("CRYPTO_IMAGE", crypto.getImageUrl());
            intent.putExtra("CRYPTO_MARKET_CAP", crypto.getMarketCap());
            intent.putExtra("CRYPTO_RANK", crypto.getMarketCapRank());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return cryptoList.size();
    }

    public void updateData(List<Cryptocurrency> newList) {
        this.cryptoList = newList;
        notifyDataSetChanged();
    }

    public static class CryptoViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        ImageView iconImageView;
        TextView nameTextView;
        TextView symbolTextView;
        TextView priceTextView;
        TextView changeTextView;

        public CryptoViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.cardView);
            iconImageView = itemView.findViewById(R.id.iconImageView);
            nameTextView = itemView.findViewById(R.id.nameTextView);
            symbolTextView = itemView.findViewById(R.id.symbolTextView);
            priceTextView = itemView.findViewById(R.id.priceTextView);
            changeTextView = itemView.findViewById(R.id.changeTextView);
        }
    }
}