package com.example.cryptoappv2.ui;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.cryptoappv2.R;

import java.util.Locale;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        
        // Get data from intent
        String name = getIntent().getStringExtra("CRYPTO_NAME");
        String symbol = getIntent().getStringExtra("CRYPTO_SYMBOL");
        double price = getIntent().getDoubleExtra("CRYPTO_PRICE", 0.0);
        double change = getIntent().getDoubleExtra("CRYPTO_CHANGE", 0.0);
        String imageUrl = getIntent().getStringExtra("CRYPTO_IMAGE");
        double marketCap = getIntent().getDoubleExtra("CRYPTO_MARKET_CAP", 0.0);
        int rank = getIntent().getIntExtra("CRYPTO_RANK", 0);
        
        // Set title
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(name);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        
        // Find views
        ImageView cryptoImageView = findViewById(R.id.detailImageView);
        TextView nameTextView = findViewById(R.id.detailNameTextView);
        TextView symbolTextView = findViewById(R.id.detailSymbolTextView);
        TextView priceTextView = findViewById(R.id.detailPriceTextView);
        TextView changeTextView = findViewById(R.id.detailChangeTextView);
        TextView marketCapTextView = findViewById(R.id.marketCapTextView);
        TextView rankTextView = findViewById(R.id.rankTextView);
        
        // Set data
        nameTextView.setText(name);
        symbolTextView.setText(symbol.toUpperCase());
        priceTextView.setText(String.format(Locale.US, "$%.2f", price));
        changeTextView.setText(String.format(Locale.US, "%.2f%%", change));
        marketCapTextView.setText(String.format(Locale.US, "$%.2f", marketCap));
        rankTextView.setText(String.valueOf(rank));
        
        if (change < 0) {
            changeTextView.setTextColor(Color.RED);
        } else {
            changeTextView.setTextColor(Color.GREEN);
        }
        
        Glide.with(this)
                .load(imageUrl)
                .into(cryptoImageView);
    }
    
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}