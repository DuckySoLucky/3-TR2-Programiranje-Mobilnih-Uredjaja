package com.example.cryptoappv2;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.cryptoappv2.adapter.CryptoAdapter;
import com.example.cryptoappv2.api.CryptoApiService;
import com.example.cryptoappv2.api.RetrofitClient;
import com.example.cryptoappv2.model.Cryptocurrency;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private CryptoAdapter adapter;
    private List<Cryptocurrency> cryptoList = new ArrayList<>();
    private SwipeRefreshLayout swipeRefreshLayout;
    private ProgressBar progressBar;
    private TextView errorTextView;
    private CryptoApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize views
        recyclerView = findViewById(R.id.recyclerView);
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        progressBar = findViewById(R.id.progressBar);
        errorTextView = findViewById(R.id.errorTextView);

        // Setup RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new CryptoAdapter(this, cryptoList);
        recyclerView.setAdapter(adapter);

        // Setup API service
        apiService = RetrofitClient.getClient().create(CryptoApiService.class);

        // Setup swipe refresh
        swipeRefreshLayout.setOnRefreshListener(this::loadCryptocurrencies);

        // Load data
        loadCryptocurrencies();
    }

    private void loadCryptocurrencies() {
        progressBar.setVisibility(View.VISIBLE);
        errorTextView.setVisibility(View.GONE);

        apiService.getCryptocurrencies("usd", "market_cap_desc", 100, 1, false)
                .enqueue(new Callback<List<Cryptocurrency>>() {
                    @Override
                    public void onResponse(Call<List<Cryptocurrency>> call, Response<List<Cryptocurrency>> response) {
                        progressBar.setVisibility(View.GONE);
                        swipeRefreshLayout.setRefreshing(false);
                        
                        if (response.isSuccessful() && response.body() != null) {
                            cryptoList.clear();
                            cryptoList.addAll(response.body());
                            adapter.notifyDataSetChanged();
                            
                            if (cryptoList.isEmpty()) {
                                errorTextView.setText(R.string.no_cryptocurrencies);
                                errorTextView.setVisibility(View.VISIBLE);
                            }
                        } else {
                            errorTextView.setText(R.string.error_loading_data);
                            errorTextView.setVisibility(View.VISIBLE);
                        }
                    }

                    @Override
                    public void onFailure(Call<List<Cryptocurrency>> call, Throwable t) {
                        progressBar.setVisibility(View.GONE);
                        swipeRefreshLayout.setRefreshing(false);
                        errorTextView.setText(getString(R.string.network_error, t.getMessage()));
                        errorTextView.setVisibility(View.VISIBLE);
                        Toast.makeText(MainActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
}