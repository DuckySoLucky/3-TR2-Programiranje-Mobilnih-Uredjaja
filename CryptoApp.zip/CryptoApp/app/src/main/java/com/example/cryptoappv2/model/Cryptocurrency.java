package com.example.cryptoappv2.model;

import com.google.gson.annotations.SerializedName;

public class Cryptocurrency {
    @SerializedName("id")
    private String id;
    
    @SerializedName("symbol")
    private String symbol;
    
    @SerializedName("name")
    private String name;
    
    @SerializedName("image")
    private String imageUrl;
    
    @SerializedName("current_price")
    private double currentPrice;
    
    @SerializedName("market_cap")
    private double marketCap;
    
    @SerializedName("market_cap_rank")
    private int marketCapRank;
    
    @SerializedName("price_change_percentage_24h")
    private double priceChangePercentage24h;
    
    @SerializedName("total_volume")
    private double totalVolume;

    public String getId() {
        return id;
    }

    public String getSymbol() {
        return symbol;
    }

    public String getName() {
        return name;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public double getCurrentPrice() {
        return currentPrice;
    }

    public double getMarketCap() {
        return marketCap;
    }

    public int getMarketCapRank() {
        return marketCapRank;
    }

    public double getPriceChangePercentage24h() {
        return priceChangePercentage24h;
    }

    public double getTotalVolume() {
        return totalVolume;
    }
}